# Body Fitness (Android)

বাংলা + English ভাষার একটি সাধারণ Android fitness planner।

## এতে যা আছে
- ৭ দিনের bodyweight workout plan
- বাংলা / English ভাষা বদল
- Balanced food guide
- Workout checkbox এবং progress counter
- কোনো account, internet permission বা paid service দরকার নেই

## APK বানানোর ধাপ
1. কম্পিউটারে Android Studio ইনস্টল করো।
2. Android Studio থেকে **Open** বেছে এই `BodyFitnessAndroid` ফোল্ডারটি খোলো।
3. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করো।
4. মেনু থেকে **Build > Build Bundle(s) / APK(s) > Build APK(s)** নির্বাচন করো।
5. Build সফল হলে Android Studio APK-এর অবস্থান দেখাবে। সাধারণত:
   `app/build/outputs/apk/debug/app-debug.apk`

## গুরুত্বপূর্ণ
- এই ZIP হলো Android Studio source project; এটি নিজে থেকে APK নয়।
- APK build করতে Android Studio/Android SDK-সহ কম্পিউটার লাগবে।
- Progress বর্তমানে অ্যাপ চলাকালীন local state-এ থাকে; অ্যাপ বন্ধ করলে reset হতে পারে।
- ব্যায়াম নিজের সামর্থ্য অনুযায়ী করবে। ব্যথা বা মাথা ঘোরা হলে থামবে।
- এটি চিকিৎসা-পরামর্শ নয়। খাবার বাদ দেওয়া বা দ্রুত শরীরের চেহারা বদলানোর চেষ্টা কোরো না।

## Build configuration
- Kotlin + Jetpack Compose
- minSdk 23 (Android 6.0)
- targetSdk 35
- App ID: `com.bodyfitness.app`
