package com.bodyfitness.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight

private data class WorkoutDay(val bn: String, val en: String, val focusBn: String, val focusEn: String, val tasksBn: List<String>, val tasksEn: List<String>)

private val plan = listOf(
    WorkoutDay("শনিবার", "Saturday", "উপরের শরীর", "Upper body",
        listOf("পুশ-আপ — ২ সেট × ৬–১০ বার", "সহজ পুশ-আপ — ২ সেট × ৬–১০ বার", "শোল্ডার ট্যাপ — ২ সেট × ১০ বার"),
        listOf("Push-up — 2 sets × 6–10", "Knee push-up — 2 sets × 6–10", "Shoulder tap — 2 sets × 10")),
    WorkoutDay("রবিবার", "Sunday", "কোর শক্তি", "Core strength",
        listOf("প্ল্যাঙ্ক — ২ × ১০–২০ সেকেন্ড", "ডেড বাগ — ২ × ৮ বার", "বার্ড ডগ — ২ × ৮ বার"),
        listOf("Plank — 2 × 10–20 sec", "Dead bug — 2 × 8", "Bird dog — 2 × 8")),
    WorkoutDay("সোমবার", "Monday", "নিচের শরীর", "Lower body",
        listOf("স্কোয়াট — ২ × ৮–১২ বার", "রিভার্স লাঞ্জ — ২ × ৬–৮ বার", "কাফ রেইজ — ২ × ১২ বার"),
        listOf("Squat — 2 × 8–12", "Reverse lunge — 2 × 6–8", "Calf raise — 2 × 12")),
    WorkoutDay("মঙ্গলবার", "Tuesday", "হালকা চলাফেরা", "Active recovery",
        listOf("২০ মিনিট আরামদায়ক হাঁটা", "হালকা স্ট্রেচিং"),
        listOf("20-minute comfortable walk", "Gentle stretching")),
    WorkoutDay("বুধবার", "Wednesday", "সম্পূর্ণ শরীর", "Full body",
        listOf("পুশ-আপ — ২ × ৬–১০", "স্কোয়াট — ২ × ৮–১২", "বার্ড ডগ — ২ × ৮", "প্ল্যাঙ্ক — ২ × ১০–২০ সেকেন্ড"),
        listOf("Push-up — 2 × 6–10", "Squat — 2 × 8–12", "Bird dog — 2 × 8", "Plank — 2 × 10–20 sec")),
    WorkoutDay("বৃহস্পতিবার", "Thursday", "কোর ও নমনীয়তা", "Core & mobility",
        listOf("ডেড বাগ — ২ × ৮", "সাইড প্ল্যাঙ্ক — ২ × ১০ সেকেন্ড", "ক্যাট-কাউ — ২ × ৮"),
        listOf("Dead bug — 2 × 8", "Side plank — 2 × 10 sec", "Cat-cow — 2 × 8")),
    WorkoutDay("শুক্রবার", "Friday", "বিশ্রাম", "Rest day",
        listOf("বিশ্রাম নাও; ইচ্ছা হলে হালকা হাঁটো"),
        listOf("Rest; optional gentle walk"))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BodyFitnessApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BodyFitnessApp() {
    var english by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }
    var selectedDay by remember { mutableIntStateOf(0) }
    val completed = remember { mutableStateListOf<String>() }
    val day = plan[selectedDay]
    val tasks = if (english) day.tasksEn else day.tasksBn
    val allCount = plan.sumOf { it.tasksBn.size }
    val title = if (english) "Body Fitness" else "বডি ফিটনেস"

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF087F5B))) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(title, fontWeight = FontWeight.Bold) },
                    actions = {
                        TextButton(onClick = { english = !english }) {
                            Text(if (english) "বাংলা" else "English")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Text("🏋️") }, label = { Text(if (english) "Workout" else "ব্যায়াম") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Text("🥗") }, label = { Text(if (english) "Food" else "খাবার") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Text("📈") }, label = { Text(if (english) "Progress" else "অগ্রগতি") })
                }
            }
        ) { padding ->
            Column(
                Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("BODY FITNESS", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                        Text(if (english) "Home training • No equipment • Healthy progress" else "বাড়িতে ব্যায়াম • কোনো সরঞ্জাম লাগবে না • সুস্থ অগ্রগতি")
                        Text(if (english) "Build strength. Stay healthy." else "শক্তি বাড়াও। সুস্থ থাকো।", fontWeight = FontWeight.SemiBold)
                    }
                }
                when (tab) {
                    0 -> {
                        Text(if (english) "Weekly workout plan" else "সাপ্তাহিক ব্যায়াম", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            plan.forEachIndexed { index, item ->
                                TextButton(onClick = { selectedDay = index }, modifier = Modifier.weight(1f)) {
                                    Text(if (english) item.en.take(3) else item.bn.take(2), fontWeight = if (selectedDay == index) FontWeight.ExtraBold else FontWeight.Normal)
                                }
                            }
                        }
                        Card {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(if (english) day.en else day.bn, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text(if (english) day.focusEn else day.focusBn, color = MaterialTheme.colorScheme.primary)
                                tasks.forEachIndexed { index, task ->
                                    val key = "$selectedDay-$index"
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = completed.contains(key), onCheckedChange = { checked ->
                                            if (checked) completed.add(key) else completed.remove(key)
                                        })
                                        Text(task, modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                        Text(if (english) "Start gently. Rest 60–90 seconds between sets. Stop if you feel pain, dizziness or unusual discomfort." else "ধীরে শুরু করো। সেটের মাঝে ৬০–৯০ সেকেন্ড বিশ্রাম নাও। ব্যথা, মাথা ঘোরা বা অস্বাভাবিক অস্বস্তি হলে থামবে।")
                    }
                    1 -> {
                        Text(if (english) "Balanced food guide" else "সুষম খাবারের গাইড", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        val meals = if (english) listOf("Breakfast: eggs, milk/yogurt, fruit and roti/oats", "Lunch: rice, fish/chicken or lentils, vegetables", "Snack: fruit, yogurt or nuts", "Dinner: rice/roti with protein food and vegetables") else listOf("সকাল: ডিম, দুধ/দই, ফল ও রুটি/ওটস", "দুপুর: ভাত, মাছ/মুরগি বা ডাল, সবজি", "বিকেল: ফল, দই বা বাদাম", "রাত: ভাত/রুটি, প্রোটিনসমৃদ্ধ খাবার ও সবজি")
                        meals.forEach { Card { Text(it, Modifier.padding(16.dp)) } }
                        Text(if (english) "Do not skip meals or follow restrictive diets. Food supports growth, recovery and strength." else "খাবার বাদ দেবে না বা কঠোর ডায়েট করবে না। বৃদ্ধি, বিশ্রাম ও শক্তির জন্য পর্যাপ্ত খাবার জরুরি।")
                    }
                    else -> {
                        Text(if (english) "Your progress" else "তোমার অগ্রগতি", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("${completed.size} / $allCount", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
                        LinearProgressIndicator(progress = { completed.size.toFloat() / allCount }, modifier = Modifier.fillMaxWidth())
                        Text(if (english) "Completed workout items on this device" else "এই ডিভাইসে সম্পন্ন ব্যায়ামের হিসাব")
                        OutlinedButton(onClick = { completed.clear() }) { Text(if (english) "Reset progress" else "অগ্রগতি রিসেট") }
                    }
                }
                HorizontalDivider()
                Text(if (english) "Health note: This app is a general fitness guide, not medical advice. At your age, prioritize regular meals, enough sleep and safe technique. Visible abs are not a measure of health." else "স্বাস্থ্য-পরামর্শ: এটি সাধারণ ফিটনেস গাইড, চিকিৎসা-পরামর্শ নয়। এই বয়সে নিয়মিত খাবার, পর্যাপ্ত ঘুম ও নিরাপদ কৌশলকে গুরুত্ব দাও। সিক্স-প্যাক থাকা সুস্থতার মাপকাঠি নয়।", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
